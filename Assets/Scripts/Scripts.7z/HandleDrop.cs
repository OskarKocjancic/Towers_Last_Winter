﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public class HandleDrop : MonoBehaviour, IDropHandler
{
    public bool canRecieve=true;
    public ScriptableBeat beat;
    public void OnDrop(PointerEventData eventData)
    {

        if (eventData.pointerDrag.transform.GetChild(transform.childCount) != null && canRecieve)
        {
            eventData.pointerDrag.transform.GetChild(eventData.pointerDrag.transform.childCount - 1).GetComponent<RectTransform>().position = GetComponent<RectTransform>().position;
            canRecieve = false;
            beat = eventData.pointerDrag.GetComponent<SpawnBeat>().beat;
        }
        else {
            Destroy(eventData.pointerDrag.transform.GetChild(eventData.pointerDrag.transform.childCount - 1).gameObject);
        }
    
}
}
