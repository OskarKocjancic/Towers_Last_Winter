﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimelineManager: MonoBehaviour
{
    [SerializeField] 
    private GameObject timelinePiece;
    private GridLayoutGroup gridLayoutGroup;
    private RectTransform rectTransform;
    [SerializeField]
    public int columns= 4;
    [SerializeField]
    public int rows= 2;
    public ScriptableBeat[,] beatmap;
    
    private void Awake()
    {
        beatmap = new ScriptableBeat[columns, rows];
        gridLayoutGroup = GetComponent<GridLayoutGroup>();
        rectTransform = GetComponent<RectTransform>();
        buildTimeline();

    }

    private void buildTimeline() {
        gridLayoutGroup.constraintCount = columns;
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < columns; j++)
            {
                GameObject g = Instantiate(timelinePiece);
                g.transform.SetParent(gameObject.transform,false);
                g.name=j+" "+i;
                gridLayoutGroup.cellSize = new Vector2( (rectTransform.rect.width-gridLayoutGroup.spacing.x*columns) / columns, (rectTransform.rect.height - gridLayoutGroup.spacing.y * rows) / rows);
            }
        }
    
 }

