﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
public class BuildAndPassArr : MonoBehaviour, IPointerClickHandler
{
    [SerializeField]
    private GameObject timeline;
    [SerializeField]
    private GameObject beatController;
    public void OnPointerClick(PointerEventData eventData)
    {
        HandleDrop[] children= timeline.GetComponentsInChildren<HandleDrop>();
        TimelineManager t = timeline.GetComponent<TimelineManager>();
        foreach (var item in children)
        {
            int x,y;
            x = System.Convert.ToInt32(item.name.Split()[0]);
            y = System.Convert.ToInt32(item.name.Split()[1]);
            if(item.beat!=null)
                t.beatmap[x, y] = item.beat;
        }
       
        PlayBeatOnTime pb = beatController.GetComponent<PlayBeatOnTime>();
        pb.beatmap = t.beatmap;
        pb.isStarted = true;
    }
}




