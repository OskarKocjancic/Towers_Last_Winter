﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class HandleDropOutside : MonoBehaviour, IDropHandler
{
    public void OnDrop(PointerEventData eventData)
    {

            Destroy(eventData.pointerDrag.transform.GetChild(eventData.pointerDrag.transform.childCount-1).gameObject);
        
    }
}
