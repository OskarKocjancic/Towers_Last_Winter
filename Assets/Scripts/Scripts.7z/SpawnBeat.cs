﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public class SpawnBeat : MonoBehaviour, IPointerDownHandler, IBeginDragHandler, IEndDragHandler,IDragHandler
{
    [SerializeField] private Canvas canvas;
    [SerializeField] public ScriptableBeat beat;
    
    private GameObject tempGameObject;
    private RectTransform rectTransform;
    private void Awake()
    {
        rectTransform = gameObject.GetComponent<RectTransform>();
    }
    public void OnPointerDown(PointerEventData eventData)
    {
        tempGameObject = new GameObject("Beat"+ transform.childCount);
        RectTransform rt = tempGameObject.AddComponent(typeof(RectTransform)) as RectTransform;
        rt.SetParent(gameObject.transform,false);
        rt.position = rectTransform.position;
        rt.localScale = rt.localScale * 0.5f;
        Image img = tempGameObject.AddComponent(typeof(Image)) as Image;
        img.sprite = beat.sprite;
        CanvasGroup cvg = tempGameObject.AddComponent(typeof(CanvasGroup)) as CanvasGroup;
        cvg.alpha = 0.6f;
        cvg.blocksRaycasts = false;
    }
    public void OnBeginDrag(PointerEventData eventData)
    {
        
    }

    public void OnDrag(PointerEventData eventData)
    {
        RectTransform rt = tempGameObject.GetComponent(typeof(RectTransform)) as RectTransform;
        rt.anchoredPosition += eventData.delta / canvas.scaleFactor;
        
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        CanvasGroup cvg = tempGameObject.GetComponent(typeof(CanvasGroup)) as CanvasGroup; 
        cvg.alpha = 1f;
        cvg.blocksRaycasts = true;
        eventData.pointerDrag = tempGameObject;
    }


}
