﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ClearTimeline : MonoBehaviour, IPointerClickHandler
{
    public GameObject timeline;
    public GameObject[] spawners;

    public void OnPointerClick(PointerEventData eventData)
    {
        foreach (HandleDrop x in timeline.GetComponentsInChildren<HandleDrop>())
        {
            x.beat = null;
            x.canRecieve = true;
        }
        foreach (GameObject y in spawners)
        {
            Transform[] children = y.GetComponentsInChildren<Transform>();
            foreach (var item in children)
            {
                Debug.Log(item.name);
                if(y!=item.gameObject)
                    Destroy(item.gameObject);
            }
        }
    }
}
